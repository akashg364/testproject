<?php 
namespace App; 
use Illuminate\Database\Eloquent\Model;
 
class Hostname extends Model
{ 
    
    protected $fillable = ['hostname', 'loopback', 'loopback999', 'sapid', 'neid', 'is_active', 'created_at', 'updated_at', 'created_by', 'updated_by'];    

    protected $table = 'master_hostname';
}
?>