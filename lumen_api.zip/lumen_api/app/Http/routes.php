<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$app->get('/', function () use ($app) {
    return $app->version();
});


/* HOSTNAME API ROUTES*/

$app->group(['prefix' => 'api/v1','namespace' => 'App\Http\Controllers'], function($app)
{
	/*Hostname Routes*/
	$app->post('hostname','HostnameController@create');
	$app->put('hostname/{id}','HostnameController@update');
	$app->delete('hostname/{id}','HostnameController@delete');
	$app->get('hostname',['middleware' => 'auth','uses' => 'HostnameController@index']);

	/*MasterLabel Routes*/
	$app->post('masterlabel','MasterLabelController@create');
	$app->put('masterlabel/{id}','MasterLabelController@update');
	$app->delete('masterlabel/{id}','MasterLabelController@delete');
	$app->get('masterlabel',['middleware' => 'auth','uses' => 'MasterLabelController@index']);


	//$app->get('mastermapping/{id}','MasterMappingController@labelValue');
	$app->get('mastermapping/{hostname}','MasterMappingController@hostnameDetails');
});







