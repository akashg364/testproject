<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Hostname;
use Validator;

class MasterMappingController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */  
    /*public function __construct(Request $request)
    {
        $request->headers->set('Content-Type', 'application/json');
    }*/

    protected function returnResponse($data)
    {
        if(empty($data['data'])) { $data_var = (object)$data['data']; } else { $data_var = $data['data']; } 
        $response = [
            'Data' =>  $data_var,
            'Response' => array(
                        'response_code' => $data['code'],
                        'status'        => $data['status'],
                        'status_msg'    => $data['statusMsg'],
                        'msg'           => $data['msg']
                    ),
            'Debug' => $data['debug']
        ];
        return response()->json($response, $data['code']);
    }

    /*get label value*/
    
    public function labelValue($id){
        
        $resultObj = DB::table('master_label_values')->where('master_label_id','=',$id)->get();
        $convertArr = json_decode(json_encode($resultObj), true);
        
        if($convertArr){
            $response_array = array(
                        'code'      => Response::HTTP_OK,
                        'status'    => Response::$statusTexts[Response::HTTP_OK],
                        'statusMsg' => 'Record has been fetched successfully',
                        'data'      => $convertArr,
                        'debug'     => "TRUE"
                    );   
        }else{

            $response_array = array(
                        'code'      => Response::HTTP_OK,
                        'status'    => Response::$statusTexts[Response::HTTP_OK],
                        'statusMsg' => 'No record found!',
                        'data'      => array(),
                        'debug'     => "TRUE"
                    );
        }
        return response()->json($response_array);
    }

    /*get hostname details*/

    public function hostnameDetails($hostname){
        
        $hostnameObj = DB::table('master_hostname')
                            ->select('master_hostname.id','master_hostname.hostname')
                            ->leftJoin('master_mapping', 'master_hostname.id', '=', 'master_mapping.master_hostname_id')
                            ->leftJoin('master_label_values', 'master_label_values.id', '=', 'master_mapping.master_label_values_id')
                            ->leftJoin('master_label', 'master_label.id', '=', 'master_mapping.master_label_id')
                            ->where('master_hostname.hostname','=',$hostname)->get();
        $hostnameArr = json_decode(json_encode($hostnameObj), true);
        echo "<pre>";print_r($hostnameArr);exit;
        if($hostnameArr){

            $mappingObj = DB::table('master_mapping')->select('id')->where('master_hostname_id','=',$hostnameArr['id'])->get();
            $mappingArr = json_decode(json_encode($mappingObj), true);

            $response_array = array(
                        'code'      => Response::HTTP_OK,
                        'status'    => Response::$statusTexts[Response::HTTP_OK],
                        'statusMsg' => 'Record has been fetched successfully',
                        'data'      => $convertArr,
                        'debug'     => "TRUE"
                    );   
        }else{

            $response_array = array(
                        'code'      => Response::HTTP_OK,
                        'status'    => Response::$statusTexts[Response::HTTP_OK],
                        'statusMsg' => 'No record found!',
                        'data'      => array(),
                        'debug'     => "TRUE"
                    );
        }
        return response()->json($response_array);
    }
 
}
