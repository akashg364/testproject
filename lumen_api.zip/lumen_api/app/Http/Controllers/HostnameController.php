<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Hostname;
use Validator;

class HostnameController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */  
    
    protected function returnResponse($data)
    {
        if(empty($data['data'])) { $data_var = (object)$data['data']; } else { $data_var = $data['data']; } 
        $response = [
            'Data' =>  $data_var,
            'Response' => array(
                        'response_code' => $data['code'],
                        'status'        => $data['status'],
                        'status_msg'    => $data['statusMsg'],
                        'msg'           => $data['msg']
                    ),
            'Debug' => $data['debug']
        ];
        return response()->json($response, $data['code']);
    }

    
    public function create(Request $request){
        
        $rules = [
            'hostname'  => 'required',
            'loopback'  => 'required',
            'loopback999'  => 'required',
            'sapid'     => 'required',
            'neid'      => 'required',
         ];
 
        $customMessages = [
             'required' => 'Please fill attribute :attribute'
        ];

        $this->validate($request, $rules, $customMessages);

        try{

            $saveData = Hostname::create($request->all());
            $response_array = array(
                    'code' => Response::HTTP_OK,
                    'data' => $saveData,
                    'status' => 'success',
                    'statusMsg' => 'Record has been created successfully',
                    'debug' => "TRUE"
                );

        } catch(\Illuminate\Database\QueryException $ex) { 

            $response_array = array(
                'code' => 500,
                'data' => array(),
                'status' => 'fail',
                'statusMsg' => $ex->getMessage(),
                'debug' => "TRUE"
            );
        }

        return response()->json($response_array);
    }
 
    public function update(Request $request, $id){

        $rules = [
            'hostname'  => 'required',
            'loopback'  => 'required',
            'loopback999'  => 'required',
            'sapid'     => 'required',
            'neid'      => 'required',
         ];
 
        $customMessages = [
             'required' => 'Please fill attribute :attribute'
        ];

        $this->validate($request, $rules, $customMessages);
        
        try {

            $updateData  = Hostname::find($id);
            $updateData->hostname = $request->input('hostname');
            $updateData->loopback = $request->input('loopback');
            $updateData->loopback999 = $request->input('loopback999');
            $updateData->sapid = $request->input('sapid');
            $updateData->neid = $request->input('neid');

            $updateData->save();
            $response_array = array(
                    'code' => Response::HTTP_OK,
                    'data' => $updateData,
                    'status' => 'success',
                    'statusMsg' => 'Record has been updated successfully',
                    'debug' => "TRUE"
                );
        
        } catch(\Illuminate\Database\QueryException $ex) { 

            $response_array = array(
                'code' => 500,
                'data' => array(),
                'status' => 'fail',
                'statusMsg' => $ex->getMessage(),
                'debug' => "TRUE"
            );
        }
        return response()->json($response_array);
        
    }  
 
    public function delete($id){

        try {
            
            $delete  = Hostname::find($id);
            $delete->delete();
            $response_array = array(
                'code' => Response::HTTP_OK,
                'data' => array(),
                'status' => 'success',
                'statusMsg' => 'Removed successfully',
                'debug' => "TRUE"
            );

        } catch(Exception $ex) { 
        
            $response_array = array(
                'code' => 500,
                'data' => array(),
                'status' => 'fail',
                'statusMsg' => $ex->getMessage(),
                'debug' => "TRUE"
            );
        }

        return response()->json($response_array);
    }
 
    public function index(){
        
        try {
            $allData  = Hostname::all();
            
            $response_array = array(
                'code' => Response::HTTP_OK,
                'data' => $allData,
                'status' => 'success',
                'statusMsg' => 'Record has been fetched successfully',
                'debug' => "TRUE"
            );

        } catch(\Illuminate\Database\QueryException $ex) { 
        
            $response_array = array(
                'code' => 500,
                'data' => array(),
                'status' => 'fail',
                'statusMsg' => $ex->getMessage(),
                'debug' => "TRUE"
            );
        }

        return response()->json($response_array); 
    }

}
